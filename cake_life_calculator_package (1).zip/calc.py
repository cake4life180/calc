
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import LinearNDInterpolator
import streamlit as st

# Initialize empty master data
master_data = []  # Example structure: [Start Age, Monthly Contribution, Milestone Age, Cash Value, Death Benefit]

# Placeholder DataFrame for user simulation
df = pd.DataFrame(master_data, columns=["Start Age", "Monthly Contribution", "Milestone Age", "Cash Value", "Death Benefit"])

# Build interpolation models
def build_interpolators(df):
    points = df[["Start Age", "Monthly Contribution", "Milestone Age"]].values
    cash_values = df["Cash Value"].values
    death_benefits = df["Death Benefit"].values
    return LinearNDInterpolator(points, cash_values), LinearNDInterpolator(points, death_benefits)

# Predict values based on user input
def predict_values(start_age, monthly_contribution):
    milestones = [18, 25, 45, 65, 85]
    user_points = np.array([[start_age, monthly_contribution, age] for age in milestones])
    cash_value_interp, death_benefit_interp = build_interpolators(df)
    predicted_cash = cash_value_interp(user_points)
    predicted_death = death_benefit_interp(user_points)
    return pd.DataFrame({"Milestone Age": milestones, "Predicted Cash Value": predicted_cash, "Predicted Death Benefit": predicted_death})

# Plot cash value and death benefit
def plot_predictions(results):
    plt.figure(figsize=(10, 6))
    plt.plot(results["Milestone Age"], results["Predicted Cash Value"], label="Cash Value")
    plt.plot(results["Milestone Age"], results["Predicted Death Benefit"], label="Death Benefit")
    plt.xlabel("Milestone Age")
    plt.ylabel("Dollars")
    plt.title("Predicted Growth Over Life Milestones")
    plt.legend()
    plt.grid(True)
    st.pyplot(plt)

# Generate a personalized summary
def generate_summary(results):
    return "\n\n".join([
        f"At age {row['Milestone Age']}, your projected cash value is ${row['Predicted Cash Value']:,.0f} and death benefit is ${row['Predicted Death Benefit']:,.0f}."
        for index, row in results.iterrows()
    ])

# Streamlit UI
st.set_page_config(page_title="Cake Life Calculator", layout="centered")

st.title("🍰 Cake Life Calculator")
st.subheader("Build a Future as Sweet as Cake")

st.markdown("""
Imagine giving your child the gift of a lifetime - a foundation of wealth, protection, and opportunity.

Use the Cake Life Calculator to see what a small monthly contribution today could turn into by the time they hit life's biggest milestones.
""")

st.write("---")

start_age = st.slider("👶 Child's Current Age:", min_value=0, max_value=18, value=4)
monthly_contribution = st.selectbox("💵 Monthly Contribution:", [250, 300, 500, 1000])

if st.button("🎂 Calculate Their Future!"):
    if len(df) > 0:
        predictions = predict_values(start_age=start_age, monthly_contribution=monthly_contribution)
        st.write("### 🎯 Milestone Predictions:")
        st.dataframe(predictions)
        st.write("### 📈 Growth Chart:")
        plot_predictions(predictions)
        st.write("### 📝 Personalized Summary:")
        st.text(generate_summary(predictions))
    else:
        st.warning("🚧 Data not available yet. Please populate master_data!")

st.write("---")

st.markdown("""
**Ready to build a plan that's perfectly baked just for your family?**

➡️ [Schedule a Custom Cake Life Plan Session](#)

Because the sweetest moments deserve the strongest foundations.
""")
