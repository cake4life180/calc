# 🍰 Cake Life Calculator

Build a Future as Sweet as Cake!

This Streamlit app helps parents visualize the future cash value and death benefit of a whole life insurance policy started for their children.

## How to run locally:
1. Install Python 3.9 or later.
2. Install required libraries:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   streamlit run calc.py
   ```

## How to deploy on Streamlit Cloud:
1. Push this repo to GitHub.
2. Create a new Streamlit app.
3. Select this repository.
4. Set the main file to `calc.py`.

Enjoy building your family's sweet financial future! 🍰
